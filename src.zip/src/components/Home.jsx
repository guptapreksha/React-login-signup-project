import React from 'react'
import {Link} from 'react-router-dom'

const Home = () => {
  return (
    <div>
      <h3>Welcome to the Home Page</h3>
      <p>
        Already have Account ? Click to <Link to="/login">login</Link>
      </p>
      <p>
        Create your Account ? Click to <Link to="/signup">SignUp  </Link>
      </p>
    </div>
  )
}

export default Home
