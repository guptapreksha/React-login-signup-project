import React from 'react'

const NoMatch = () => {
  return (
    <div>
      Page not Found
    </div>
  )
}

export default NoMatch


